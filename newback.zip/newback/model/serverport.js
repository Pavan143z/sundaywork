const mongoose= require('mongoose')
const Schema= mongoose.Schema;

const ServerPort = new Schema({
    post:{type: String}
},{
    collection: 'userpost'
})

module.exports= mongoose.model('userpost', ServerPort)

