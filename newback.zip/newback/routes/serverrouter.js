const express= require('express')
const app= express()
const ServerPortRouter = express.Router()

const ServerPort =require('../model/app')
const ServerPort2 =require('../model/app1')
const PostServerPort =require('../model/serverport')
const JobPostServerPort=require('../model/jobserverport')
const skillPostServerPort=require('../model/skillschema')
const expPostServerPort=require('../model/exp')

ServerPortRouter.route("/Signup").post(function(req, res) {
    const serverport = new ServerPort(req.body);
    serverport
      .save()
      .then(serverport => {
        res.json("User added Successfully");
      })
      .catch(err => {
        res.status(400).send("unable to save to database");
      });
  });
  
  ServerPortRouter.route("/register").post(function(req, res) {
      const serverport = new ServerPort2(req.body);
      serverport
        .save()
        .then(serverport => {
          res.json("User added Successfully");
        })
        .catch(err => {
          res.status(400).send("unable to save to database");
        });
    });
    ServerPortRouter.route("/Signup").get(function(req, res) {
        ServerPort.find(function(err, serverports) {
          if (err) {
            console.log(err);
          } else {
            res.json(serverports);
          }
        });
      });
      
      ServerPortRouter.route("/register").get(function(req, res) {
          ServerPort2.find(function(err, serverports) {
            if (err) {
              console.log(err);
            } else {
              res.json(serverports);
            }
          });
        });
//post part
ServerPortRouter.route('/userhome').post(function(req,res){
    const serverport =new PostServerPort(req.body)
    serverport.save().then(serverport=>{
        res.json('Post added Successfully')
    })
    .catch(err=>{
        res.status(400).send("unable to save to database")
    })
})
ServerPortRouter.route('/userhome').get(function(req,res){
    PostServerPort.find(function(err,serverports){
        if(err){
            console.log(err)
        } else{
            res.json(serverports)
        }
    })
})
//addjobpost
ServerPortRouter.route('/PostJob').post(function(req,res){
    const jobserverport =new JobPostServerPort(req.body)
    jobserverport.save().then(jobserverport=>{
        res.json('Job Post added Successfully')
    })
    .catch(err=>{
        res.status(400).send("unable to save to database")
    })
})
ServerPortRouter.route('/PostJob').get(function(req,res){
    JobPostServerPort.find(function(err,serverports){
        if(err){
            console.log(err)
        } else{
            res.json(serverports)
        }
    })
})
//add skill
ServerPortRouter.route('/showskill').post(function(req,res){
  const skillserverport =new skillPostServerPort(req.body)
  skillserverport.save().then(skillserverport=>{
      res.json('Skills added Successfully')
  })
  .catch(err=>{
      res.status(400).send("unable to save to database")
  })
})
ServerPortRouter.route('/showskill').get(function(req,res){
  skillPostServerPort.find(function(err,serverports){
      if(err){
          console.log(err)
      } else{
          res.json(serverports)
      }
  })
})
//add expierence



ServerPortRouter.route('/addexp').post(function(req,res){
    const skillserverport =new expPostServerPort(req.body)
    skillserverport.save().then(skillserverport=>{
        res.json('exp added Successfully')
    })
    .catch(err=>{
        res.status(400).send("unable to save to database")
    })
  })
  ServerPortRouter.route('/addexp').get(function(req,res){
    expPostServerPort.find(function(err,serverports){
        if(err){
            console.log(err)
        } else{
            res.json(serverports)
        }
    })
  })
module.exports= ServerPortRouter