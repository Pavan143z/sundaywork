import React, { Component } from 'react'
import NavComponent from '../navcomponent';

export class About extends Component {
  render() {
    return (
      <div>
           <NavComponent/>
          <h1>About Us..</h1>
          <p align="justify">
            This web application is a social networking site designed specifically for the
            business community. The goal of the site is to allow registered members to establish
            and document networks of people they know and trust professionally. A user’s profile 
            page, which emphasizes skills, employment history and education, has professional
            network news feeds and a limited number of customizable modules. To get in touch 
            with other users, this application requires them to be connected. If a user accepts 
            connection request from another user, only then both of them can view each other’s
            posts and their profile. In addition, the user can agree with the post of other user
            by liking his/her post or can also share their own view-point by commenting on that
            post. This application provides a chatting component, using which the user can 
            communicate privately withhis/her connections.Besides, this application has a company
            module, where various organizations can create their profile, after which can post 
            for vacancies or recruitment details. Any user following that company can view/apply
            for the jobs.
             </p>
      </div>
    )
  }
}

export default About
