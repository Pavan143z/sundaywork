import React from "react";


class MainHome extends React.Component {
  render() {
    return (
      <div className="container">
 
        <div className="row">
        <h2>Your professional profile with personality</h2>
          
          <div className="col-lg-8">
            <br />
            <br />
            <br />
            <h3 className="text-primary">
            Job search smarter with the LinkedIn app. Give your job search a boost by using our enhanced job search to filter through the millions of job openings to find the right ones for you. Create job search alerts, ask for referrals from your network, 
            and apply with your resume or professional profile in just a few taps.
            </h3>
  
        
          </div>
          <div className="col-lg-4">
            <br />
            <br />
            <br />
            <img
              src={require("../assets/images/back.jpg")}
              className="img-fluid"
              width="300px"
              height="300px"
            />
          </div>
        </div>
      </div>
    );
  }
}

export default MainHome;
