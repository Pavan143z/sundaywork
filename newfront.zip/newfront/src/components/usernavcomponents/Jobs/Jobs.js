import React, { Component } from "react";
import ManageJobs from "./Organization/managejobs";
import axios from 'axios';
class Jobs extends Component {
    constructor() {
        super()
        this.state = { jobpost: [] }
    
    }
    baseurl = "  http://localhost:3002/PostJob";
    getPost = () => {
        axios.get(this.baseurl).then((response) => {
            this.setState({ jobpost: response.data })
            console.log(this.state.jobpost)
        });
    }
    componentDidMount() {
        this.getPost();
    }
    render() {
        return (
            <div>
                <ManageJobs/>
                <h4> {this.state.jobpost.map((contact) =>
                <div>
                  <h4 key={contact}>
                  <h4>{contact.jobpost}</h4>
                  </h4>
                </div>
                )
                }
            </h4>
            </div>
        );
    }
}

export default Jobs;