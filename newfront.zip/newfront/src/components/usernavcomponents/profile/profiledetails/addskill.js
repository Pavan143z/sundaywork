import React from 'react'
import { FormInputs } from "../FormInputs/FormInputs";
import UserNavComponent from '../../../usernavcomponent';
import axios from 'axios';
class AddSkill extends React.Component {
  constructor(props) {
    super(props);
  
    this.onChangeplang = this.onChangeplang.bind(this);
    this.onChangeSkill = this.onChangeSkill.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    this.state = {
      plang: "",
      skill: ""
     
    };
  }
  onChangeplang(e) {
    this.setState({
      plang: e.target.value
    });
  }

  onChangeSkill(e) {
    this.setState({
      skill: e.target.value
    });
  }

 
  onSubmit(e) {
    e.preventDefault();
    const addskill = {
      plang: this.state.plang,
      skill: this.state.skill
    };
    
    axios.post("http://localhost:3002/showskill", addskill).then(function (response) {
      console.log(response.data);
    });
    this.props.history.push('/showskill');
  }
    render(){
        return(
          <div>
       <UserNavComponent/>
          <div className="container" > 
              <div className="border border-dark" align="center">
               <div className="col-lg-5" >
                 <form onSubmit={this.onSubmit}  >
                   <div className="form-group">
                     <label className="text-info">
                       {" "}
                       <h3>  Languages </h3>
                     </label>
                     <input
                       type="text"
                       className="form-control"
                       placeholder="Programing Language"
                       value={this.state.plang}
                       onChange={this.onChangeplang}
                       required
                     />
                   </div>
                   <div className="form-group">
                     <label className="text-info">
                       <h3>Skills </h3>
                     </label>
                     <input
                       type="text"
                       className="form-control"
                       placeholder="Skills"
                       value={this.state.skill}
                       onChange={this.onChangeSkill}
                       required
                     />
                   </div>
                   <br />
                   <div className="form-group">
                     <input
                       type="submit"
                       value="Add Skill"
                       className="btn btn-info"
                     />
                   </div>
                 </form>
               </div>
               </div>
             </div>
             <hr/>
          </div>
        )
    }
}
export default AddSkill