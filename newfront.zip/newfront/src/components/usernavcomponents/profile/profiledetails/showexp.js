import React, { Component } from 'react'
import UserNavComponent from '../../../usernavcomponent';
import axios from "axios";
export class Showexp extends Component {
    constructor() {
        super()
        this.state = { exp: [] }
    
    }
    baseurl = "  http://localhost:3002/addexp";
    getexp = () => {
        axios.get(this.baseurl).then((response) => {
            this.setState({ exp: response.data })
            console.log(this.state.exp)
        });
    }
    componentDidMount() {
        this.getexp();
    }
    render() {
        return (
            <div>
                <UserNavComponent/>
                <h2>Expierence Information</h2>
                <h4> {this.state.exp.map((expi) =>
                <div>
                  <h4 key={expi}>
                  <h4>previous company&nbsp;&nbsp; {expi.prevcompany}&nbsp;&nbsp;<br/>years&nbsp;&nbsp;
                   {expi.years}</h4>
                 
                  </h4>
                </div>
                )
                }
            </h4>
            </div>
        );
    }
}

export default Showexp
