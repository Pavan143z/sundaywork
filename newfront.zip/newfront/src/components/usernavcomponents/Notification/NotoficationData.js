import React from 'react';
import styled from 'styled-components';
import {Link} from 'react-router-dom';
 function NotificationData(props) {
   
    const PromotedStyles = styled.div`
    width: 550px;
    border: 1px solid #CACCCE;
    padding: 5px;
    margin: 0 15px;
    background-color: #FFFFFF;
    box-shadow: -2px 4px #D0D3D6;
   
    h1 {
      float: left;
      margin 15px 15px;
      color: #CACCCE;
    }

  `;
    return (
        <PromotedStyles className='promoted'>
            <div>
                <div >
               
                    <img width="125px" src={props.noti.imageUrl} />
                    
                    <span className="MyLinkText">
                        {props.noti.text}
                    </span><button className="btn btn-danger btn-sm" align="right" >X</button> 
                    <br/><br/>
                    <br/><br/>
                     <button className="btn btn-secondary btn-sm"  ><Link to='/userjob'>View Jobs</Link></button> 
                </div>
            </div>
        </PromotedStyles>
    )
}

export default NotificationData